namespace console_hero.Models.Items;

public abstract class OneHandedWeapon(char symbol, string name, int damage): Item(symbol, name), IEquippable,  IWeapon
{
    public int BaseDamage { get; } = damage;

    public override bool UseFromInventory(Player player)
    {
        return Equip(player); 
    }
    public bool Equip(Player player)
    {
        IEquippable? item = null;
        if (player.Hands.Left == player.Hands.Right)
        {
            item = player.Hands.ReleaseFromLeft();
            player.Hands.ReleaseFromRight();
        }
        else
        {
            item = player.Hands.ReleaseFromRight();
        }

        player.Hands.EquipRight(this);
        player.Inventory.RemoveItem(this);
        
        player.Inventory.AddItem(item);
        return true;
    }
    public void Attack(){}
}

public class KnightsSword(char symbol, string name, int damage) : OneHandedWeapon(symbol, name, damage);